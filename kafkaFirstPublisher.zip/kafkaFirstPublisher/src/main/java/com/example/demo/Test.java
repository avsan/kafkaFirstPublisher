package com.example.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Address a1=new Address();
		a1.setStreet("a");
		a1.setZip("z-a");
		
		Address a2=new Address();	
		a2.setStreet("b");
		a2.setZip("z-b");
		Address a3=new Address();	
		a3.setStreet("c");
		a3.setZip("z-c");
		Address a4=new Address();
		a4.setStreet("d");
		a4.setZip("z-d");

		List<Address> ls1=new ArrayList<>();
		ls1.add(a1);
		ls1.add(a2);
		ls1.add(a3);
		ls1.add(a4);
		
		//System.out.println(ls1);
		
		Address b1=new Address();
		b1.setStreet("1");
		b1.setZip("z-1");
		Address b2=new Address();
		b2.setStreet("2");
		b2.setZip("z-2");
		Address b3=new Address();	
		b3.setStreet("3");
		b3.setZip("z-3");
		Address b4=new Address();
		b4.setStreet("4");
		b4.setZip("z-4");
		List<Address> ls2=new ArrayList<>();
		ls2.add(b1);
		ls2.add(b2);
		ls2.add(b3);
		ls2.add(b4);
		
		User user=new User();
		user.setId(0);
		user.setName("Test");
		user.setAddress(ls1);
//		/System.out.println(ls1);
		User user1=new User();
		user1.setId(1);
		user1.setName("Test----");
		user1.setAddress(ls2);
		
		
	
		System.out.println("User "+user);
		System.out.println("User 1 "+user1);
		IntStream.range(0, user.getAddress().size())
	    .parallel()
	    .forEach(i -> {
	        if (i < user1.getAddress().size()) user.getAddress().get(i).setStreet(user1.getAddress().get(i).getStreet() );
	        user.getAddress().get(i).setZip(user1.getAddress().get(i).getZip() );
	    });
		System.out.println("After Update of list"+user.toString());
	}

}
