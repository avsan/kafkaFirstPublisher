
package com.example.demo.controller;

import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.User;

@RestController
public class TestController {

	@Autowired
	private KafkaTemplate<String, Object> template;

	private String topic = "test";

	@GetMapping("/publish/{name}")

	public String publishMessage(@PathVariable String name) throws InterruptedException, ExecutionException {

		ListenableFuture<SendResult<String, Object>> send = template.send(topic, "1234", "hi  " + name);
		SendResult<String, Object> sendResult = send.get();
		String key = sendResult.getProducerRecord().key();
		System.out.println(key);
		return "Data Published";

	}

	@GetMapping("/publish/json/{name}")

	public String publishJSONMessage(@PathVariable String name) throws InterruptedException, ExecutionException {

		User user = new User();

	

		
	
		template.send(topic, user);
		return "Data Published";

	}
}
