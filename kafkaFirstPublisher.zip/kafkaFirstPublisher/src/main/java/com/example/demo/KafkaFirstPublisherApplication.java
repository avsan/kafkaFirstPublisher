package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaFirstPublisherApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaFirstPublisherApplication.class, args);
	}

}
